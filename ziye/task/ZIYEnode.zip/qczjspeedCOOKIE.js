

//独立COOKIE文件     ck在``里面填写，多账号换行
let GetUserInfoheaderVal= ``
let taskbodyVal= ``
let activitybodyVal= ``
let addCoinbodyVal= ``
let addCoin2bodyVal= ``


let qczjcookie = {
  GetUserInfoheaderVal: GetUserInfoheaderVal,  
  taskbodyVal: taskbodyVal,
  activitybodyVal: activitybodyVal,
  addCoinbodyVal: addCoinbodyVal,
  addCoin2bodyVal: addCoin2bodyVal,    

}

module.exports =  qczjcookie
  


